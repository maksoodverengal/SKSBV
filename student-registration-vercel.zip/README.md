# Student Registration — Vercel + Google Sheets

## What this does

Website fields:
- Name
- Phone Number
- Class (1–10)
- Photo

The submission is saved to a Google Sheet and the photo is saved in a Google Drive folder. The sheet stores the photo's Drive URL.

## Google setup

1. Create a Google Sheet.
2. Rename the first tab to `Responses`.
3. Add these headers in row 1:
   `Timestamp | Name | Phone Number | Class | Photo`
4. Create a Google Drive folder for photos and copy its folder ID.
5. In the Sheet, open **Extensions → Apps Script**.
6. Paste `google-apps-script/Code.gs`.
7. Replace `PASTE_GOOGLE_DRIVE_FOLDER_ID_HERE`.
8. Deploy → New deployment → Web app.
9. Set **Execute as: Me**.
10. Set **Who has access: Anyone**.
11. Copy the Web App URL.

## Vercel setup

1. Put this project in a GitHub repository, or use the Vercel CLI.
2. Open `config.js`.
3. Replace `PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE` with the Web App URL.
4. Deploy the project to Vercel.
5. Open the Vercel URL and submit a test registration.

## Important

The photo is uploaded to Google Drive; it is not stored inside the Google Sheet. The Sheet receives the Drive file URL.

This is intended for small/normal registration traffic and is subject to Google Apps Script, Drive, and Sheets quotas.
